package action;

public class MovementActionPoints {
	public static float ProximityBonus = 1.5f;
	
	public static float CloserToAlly = 1;
	public static int FurtherToAlly = 1;
	public static int CloserToEnemy = 80000;
	public static int FurtherToEnemy = 1;
	public static int ConstrainEnemyPosition = 1000;
	public static float CloserToWeaponPickup = 10000;
	public static int CloserToControlPoint = 500;
	public static int CloserToMainFrame = 2000;
	public static int MoreRangeInMovement = 100;
	public static int MoreRangeInShooting = 100;
}
