package action;

public class OtherActionPoints {
	public static int PlayerHealthLowMainFrame = 10000;
	public static int PickupWeapon = 20000;
	public static int ActivateShield = 500;
}
