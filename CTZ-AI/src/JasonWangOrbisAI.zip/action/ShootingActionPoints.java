package action;

public class ShootingActionPoints {
	public static int KillsLastEnemy = 100000000;
	public static int KillsEnemy = 1000000;
	public static int DoubleDamage = 400000;
	public static int NormalDamage = 200000;
}